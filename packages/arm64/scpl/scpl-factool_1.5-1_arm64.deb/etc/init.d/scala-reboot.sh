#!/bin/sh

if [ ! -f /etc/init.d/scala-reboot.count ] ; then
	echo "0" > /etc/init.d/scala-reboot.count
	echo " " >> /etc/init.d/scala-reboot.record
else
	read REBOOT_COUNT_STRESS_TEST < /etc/init.d/scala-reboot.count
fi

TIME=$(date "+%Y-%m-%d %H:%M:%S")
REBOOT_COUNT_STRESS_TEST=$(($REBOOT_COUNT_STRESS_TEST+1))
RECORD="${REBOOT_COUNT_STRESS_TEST} ${TIME}"
echo $REBOOT_COUNT_STRESS_TEST > /etc/init.d/scala-reboot.count
echo $RECORD >> /etc/init.d/scala-reboot.record
sync

reboot

